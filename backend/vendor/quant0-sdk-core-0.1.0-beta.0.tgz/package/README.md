# @quant0/sdk-core

The TypeScript shim for the quant0 Edge Plane — **zero cryptography**, ~300
lines. It is a telephone to the local `q0-agent`: the agent holds the cached
JWKS + permission slip and does all the in-process crypto (post-quantum hybrid
or classical, the platform's choice); this package just asks it to verify or
mint a token and hands you the claims.

> Why a shim and not a verifier? Because shipping a composite ML-DSA verifier
> into four languages means reimplementing unaudited crypto four times and
> re-releasing every SDK on each NIST/CVE change. Here the crypto lives in
> exactly one audited Rust core (`crates/qzero-crypto` → `q0-agent`). Algorithm
> agility is a change to the agent binary; your code never moves.

## The path ladder

`Quant0Client` negotiates a verification path at first use:

1. **local agent** (default, wired) — the q0-agent loopback Workload API.
2. **embedded core** — the WASM build of the crypto core, for runtimes with no
   agent (browser / serverless). Defined but not yet wired (wasm32 build pending).
3. **remote API** — hosted verification. Defined for completeness.

Your code is identical regardless of which path answered.

## Install & run

```bash
npm install @quant0/sdk-core
```

Run a `q0-agent` next to your app (sidecar in k8s; loopback on a VM). It exposes
the Workload API on `http://127.0.0.1:9595` by default; override with
`new Quant0Client({ agentUrl })`.

## Quickstart

```ts
import { Quant0Client } from "@quant0/sdk-core";

const q0 = new Quant0Client();
const claims = await q0.verify(bearerToken); // throws InvalidTokenError if untrusted
// claims.subject, claims.orgId, claims.appPermissions, ...
```

Express and Next.js adapters live at `@quant0/sdk-core/express` and
`@quant0/sdk-core/nextjs`. See [`llms.txt`](./llms.txt) and
[`examples/`](./examples).

## Develop

```bash
npm install
npm test          # vitest unit tests (no agent needed — fetch is stubbed)
npm run build     # tsc → dist/
```

## Status

Beta (parallels OpenAPI ~63% parity for the management client, shipped
separately). The agent verification path is production-ready; conformance
fixtures binding all paths to a cross-language source of truth land in E8.
